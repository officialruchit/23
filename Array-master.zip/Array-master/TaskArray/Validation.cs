﻿using System;

namespace TaskArray
{
    /// <summary>
    /// Contains methods for validating user input.
    /// </summary>
    internal class Validation
    {
        /// <summary>
        /// Validates user input within a specified range.
        /// </summary>
        /// <param name="prompt">The prompt message displayed to the user.</param>
        /// <param name="input">The variable to store the validated input.</param>
        /// <param name="min">The minimum allowed value.</param>
        /// <param name="max">The maximum allowed value.</param>
        /// <param name="invalidMessage">The message displayed for invalid input.</param>
        /// <param name="invalidMessageForMin">The message displayed for input below the allowed range.</param>
        /// <param name="invalidMessageForMax">The message displayed for input above the allowed range.</param>
        public static void validate(string prompt,out int input, int min, int max, string invalideMessage, string invalideMessageForMin, string invalideMessageForMax)
        {
            while (true)
            {
                Console.Write($"{Environment.NewLine} {prompt} ");
                string inputString = Console.ReadLine();

                string validationResult = Utility.ValidateInput(inputString, out input, min, max);

                if (validationResult == "Invalid")
                {
                    Console.WriteLine($"{Environment.NewLine} {invalideMessage}");
                }
                else if (validationResult == "ErrorForMin")
                {
                    Console.WriteLine($"{Environment.NewLine} {invalideMessageForMin}.");
                }
                else if (validationResult == "ErrorForMax")
                {
                    Console.WriteLine($"{Environment.NewLine} {invalideMessageForMax}.");
                }
                
                else
                {           
                    return;
                }
                
            }
        }

        /// <summary>
        /// Method to validate the user input for column
        /// </summary>
        /// <returns>A valid column as X or Y</returns>
        public static char validateColumn(string selectTheColumn, string invalidMessageForColumn)
        {
            while (true)
            {
                Console.Write($"{Environment.NewLine}  {selectTheColumn}");
                string input = Console.ReadLine().Trim().ToLower();
                if (string.IsNullOrWhiteSpace(input) || (input != "x" && input != "y"))
                {
                    Console.WriteLine($"{Environment.NewLine}  {invalidMessageForColumn}");
                    continue;
                }
                return Char.ToUpper(input[0]);
            }
        }
    }
}




