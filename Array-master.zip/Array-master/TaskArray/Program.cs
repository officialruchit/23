﻿using System;
namespace TaskArray
{
    /// <summary>
    /// Program for sorting a 2D array based on user input for column and order.
    /// </summary>
    internal class Program
    {
       
        /// <summary>
        /// program take 2d array from the user and accoring column and order display array in ascending order or descending order
        /// </summary>
        static void Main()
        {

            Utility.HeadingofThePrograme();
            Validation.validate(Constant.SelectTheNumOfTheRow, out int rowSize, Constant.minRowRange, Constant.maxRowRange,Constant.arrayElementsOutOfTheRange,Constant.InvalidMessageForArraySize, Constant.InvalidMessageForArraySize);
            int[,] array = new int[rowSize, 2];
            Array.GetArrayElements(array);
            Console.WriteLine($"{Environment.NewLine}  You have enter below array values:");
            Console.WriteLine(Constant.xAndY);
            Console.WriteLine("  ------------------");
            Array.DisplayArray(array);
            char selectedColumn = Validation.validateColumn(Constant.selectTheColumn, Constant.invalidMessageForColumn);
            Validation.validate(Constant.selectTheOrder, out int order, 1, 2,Constant.invalidMessageForOrder,Constant.outOfRangeForOrder, Constant.outOfRangeForOrder);
            Array.SortArray(array, selectedColumn, order);
            Console.Write($"{Environment.NewLine}  ");
            Console.WriteLine($"{Constant.TwoDArray}");
            Console.WriteLine(Constant.xAndY);
            Console.WriteLine("  ------------------");
            Array.DisplayArray(array);
            Console.ReadKey();
        }
    }
}
