﻿namespace TaskArray
{
    /// <summary>
    /// Contains constant values used in the program.
    /// </summary>
    internal class Constant
    {
        public const int minRowRange = 1;
        public const int maxRowRange = 10;
        public const int minRowElements = -2147483648;
        public const int maxRowElememts = 2147483647;
        public static string EnterElements = "Enter element for";
        public static string enterTheElements= "  ";
        public static string InvalidMessageForArrayElements = "Array sorting : [Error] Entered array elements is invalid.";
        public const string arrayElementsOutOfTheRange = " Array sorting : [Error] Entered array elements size is invalid.";
        public static string SelectTheNumOfTheRow = " Input Array Row Count[1 to 10]:";
        public static string InvalidMessageForArraySize = " Array sorting : [Error] Entered array size is invalid.";
        public static string selectTheColumn = "On which column you want to sort (Enter X/x or Y/y):";
        public static string invalidMessageForColumn = "Array sorting : [Error] Entered sorting column is invalid.";
        public static string selectTheOrder = " Which sorting type you want to apply (Enter 1 for Ascending sorting, 2 for Descending sorting: ";
        public static string invalidMessageForOrder = " Array sorting : [Error] Entered sorting order is invalid.";
        public static string outOfRangeForOrder = " Array sorting : [Error] Entered sorting order is out of the predefined range.";
        public static string xAndY = "  X".PadRight(13) + "  Y";
        public static string TwoDArray = "Sorted 2D array :";
        
    }
}
