﻿using System;
namespace TaskArray
{
    internal class Array
    {

        /// <summary>
        /// Method to validate the user input for array
        /// </summary>
        /// <param name="array">A valid array in range of -2147483648 to 2147483647 </param>
        public static void GetArrayElements(int[,] array)
        {
            for (int i = 0; i < array.GetLength(0); i++)
            {
                Console.Write($"{Environment.NewLine}");
                for (int j = 0; j < array.GetLength(1); j++) 
                {           
                    bool check = true;
                    while (check)
                    {
                        Console.Write($"  {Constant.EnterElements} [{i}, {j}]:  ");
                        if (int.TryParse(Console.ReadLine().Trim(), out array[i, j]) == false)
                        {
                            Console.WriteLine($"{Environment.NewLine}  {Constant.InvalidMessageForArrayElements}\n");
                            continue;
                        }
                        if (array[i,j] < -2147483648 || 2147483647 < array[i,j] )
                        {
                            Console.WriteLine($"{Environment.NewLine}  {Constant.arrayElementsOutOfTheRange}");
                            continue;
                        }
                        else
                        {
                            check = false;
                        }
                    }
                }
            }
        }

        /// <summary>
        ///  Display the array
        /// </summary>
        /// <param name="array">A array which contain data</param>
        public static void DisplayArray(int[,] array)
        {
             for (int i = 0; i < array.GetLength(0); i++)
             {
                  Console.Write("  " + array[i, 0].ToString().PadRight(13));
                  Console.WriteLine(array[i, 1]);
             }
        }

        /// <summary>
        /// Method implement sorted array in ascedning order or descending order
        /// </summary>
        /// <param name="array">A array which contain data</param>
        /// <param name="sortingColumn">A sortingColumn which contain valid column</param>
        /// <param name="sortingOrder">A sortingOrder which contain valid order for sorting</param>
        public static void SortArray(int[,] array, char sortingColumn, int sortingOrder)
        {
            int rowCount = array.GetLength(0);
            for (int i = 0; i < rowCount - 1; i++)
            {
                for (int j = 0; j < rowCount - i - 1; j++)
                {
                    bool shouldSwap = ShouldSwap(array[j, sortingColumn - 'X'], array[j + 1, sortingColumn - 'X'], sortingOrder);
                    if (shouldSwap)
                    {
                        for (int k = 0; k < 2; k++)
                        {
                            int temp = array[j, k];
                            array[j, k] = array[j + 1, k];
                            array[j + 1, k] = temp;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Method compare the order and check elements should be swapped or not
        /// </summary>
        /// <param name="a">A first row from selected column</param>
        /// <param name="b">A secound row from selected column</param>
        /// <param name="sortingOrder">A selected sorting order 1 or 2</param>
        /// <returns> shouldSwapp elements or not</returns>
        public static bool ShouldSwap(int a, int b, int sortingOrder)
        {
            if (sortingOrder == 1)
                return a > b;
            else
                return a < b;
        }

    }
}
