﻿using System;

namespace TaskArray
{
    internal class Utility
    {
        /// <summary>
        /// Displays the heading of the program in the console.
        /// </summary>
        public static void HeadingofThePrograme() {
            Console.WriteLine($"{Environment.NewLine}  |============================================================|");
            Console.WriteLine("    soring of two dimentional array");
            Console.WriteLine("  |============================================================|");
        }

        /// <summary>
        /// Validates user input for integers within a specified range.
        /// </summary>
        /// <param name="inputString">The input string to be validated.</param>
        /// <param name="input">The parsed integer input.</param>
        /// <param name="min">The minimum allowed value.</param>
        /// <param name="max">The maximum allowed value.</param>
        /// <returns>A string indicating the validation result ("Invalid", "ErrorForMin", "ErrorForMax", or "Valid").</returns>
        public static string ValidateInput(string inputString, out int input, int min, int max)
        {
            if (int.TryParse(inputString, out input)==false)
            {
                return "Invalid";
            }
            if (input < min)
            {
                return "ErrorForMin";
            }
            if (input > max)
            {
                return "ErrorForMax";
            }
           
            return "Valid";
        }

    }
}
